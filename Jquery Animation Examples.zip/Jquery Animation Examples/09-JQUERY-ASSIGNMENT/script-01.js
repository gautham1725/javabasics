$( function() {
	
	$("#h12").toggle();
	$("#h11").slideUp(2000);
	$("#h12").delay(2000).slideDown(2000);

	$(".red-box").delay(4000).fadeOut(2000);
	$(".green-box").delay(6000).fadeOut(2000);
	$(".blue-box").delay(8000).fadeOut(2000);

}
);
