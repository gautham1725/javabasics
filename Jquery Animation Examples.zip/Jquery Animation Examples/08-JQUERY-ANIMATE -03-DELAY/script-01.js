$( function() {
	$(".red-box").fadeOut(2000);
	$(".green-box").delay(2000).fadeOut(2000);
	$(".blue-box").delay(4000).fadeOut(2000);
}
);
