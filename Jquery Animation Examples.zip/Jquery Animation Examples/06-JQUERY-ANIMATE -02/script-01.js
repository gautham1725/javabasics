$( function() {
	$(".blue-box").animate( {
		"margin-left" : "500px",
		"width" : "50px",
		"height" : "50px",
		"opacity" : "0.1",
		"margin-top" : "60px"
	} , 4000 , "swing"
);
}
);
