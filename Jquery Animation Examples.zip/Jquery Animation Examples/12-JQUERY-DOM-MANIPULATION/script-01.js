$( function() {


//---------------------------------------------------------------------
//	$("ul ul").append("<li> 2019 world champion</li>");
//	$("div#div1").prepend("<h1> Inside div </h1>");
//	$(".blue-box").append(" World No.1  bowler");
//	$(".blue-box").css("color" , "white");
//	$(".blue-box").after(" <div class='red-box' > Rishabh </div> ");
//	$(".blue-box").before(" <div class='red-box' > Rishabh </div> ");
//	$(".blue-box").after($(".green-box"));
//----------------------------------------------------------------------


//$("li li:odd").replaceWith("<li>Replaced List</li>");

//$(" .red-box , .blue-box").replaceWith( function(){
//	return " <div class='green-box'>Replaced</div>"
//} );

//----------------------------------------------------------------------



//$("<div class='red-box'>Replaced</div>").replaceAll(".red-box , .blue-box");
//$("li li").remove();

//----------------------------------------------------------------------

//var detachElement = $("li").detach();
//$("body").append(detachElement );

//$("p:first").empty();

//$(".red-box , .blue-box , .green-box").empty();

//----------------------------------------------------------------------

var mylink = $("#mylink");
console.log(mylink.attr("href"));
mylink.attr("href" , "http://www.facebook.com" );
console.log(mylink.attr("href"));


//----------------------------------------------------------------------

//var textInp = $("input:text");
//textInp.val("gowtham");
//var rangeInp = $("input[type='range']");
//console.log(textInp.val());
//console.log(rangeInp.val());

//----------------------------------------------------------------------

//var checkBox = $("input:checkbox");
//console.log(checkBox.prop("checked"));

//---------------------css-------------------------------------------------

var redBox = $(".red-box");
//console.log(redBox.css('width'));
//console.log(redBox.width());

//$("p:first").css("font-size" , "20px" );
//$(".red-box").css("background-color" , "black")

//---------------------dont copy-------------------------------------------------

redBox.css("user-select" , function(){
	return "none";
});

});