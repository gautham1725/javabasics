console.log("inside script");
$( function() {
	$( ".red-box" ).fadeToggle();
	console.log("inside function");
	$( ".red-box" ).delay(2000).fadeIn(200);
} );