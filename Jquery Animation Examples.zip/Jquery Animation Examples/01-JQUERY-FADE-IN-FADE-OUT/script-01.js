$( function() {
	$(".green-box").fadeOut(2000);
	$(".green-box").fadeIn(2000);
} );