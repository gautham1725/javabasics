$( function() {
	$( ".red-box" ).slideUp(3000);
	$( ".red-box" ).slideDown(3000);
} );