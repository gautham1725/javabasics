$( function() {
	$(".blue-box").animate( {
		"margin-left" : "300px"
	} , 4000 , "swing"
);
	$(".green-box").delay(2000).animate( {
		"margin-left" : "300px"
	} , 4000 , "swing"
);
	$(".red-box").delay(4000).animate( {
		"margin-left" : "300px"
	} , 4000 , "swing"
); 
}
);
