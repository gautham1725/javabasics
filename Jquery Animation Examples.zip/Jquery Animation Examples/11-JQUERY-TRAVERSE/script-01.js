$( function() {

	$("p").css("background-color" , "yellow" );	
	$("input[type='text']").css("background-color" , "rgba(180,180,300,0.8)" );

	$(".blue-box").css("background-color" , "blue" );

	$("div").css("color" , "white" );

	$("p:even").css("background-color" , "rgba(100,100,300,0.8)" );

	$("#list1").css("background-color" , "rgba(300,10,100,0.5)" );
} );