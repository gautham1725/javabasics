$( function() {
	$( ".red-box" ).hide(3000);
	$( ".red-box" ).show(3000);

	$( "p" ).hide(3000);
	$( "p" ).show(3000);
} );