$( function() {
	$("p").animate( {
		"font-size" : "20",
	//	"font-family" : "mistral",
		"opacity" : "0.4"
	} , 4000 , "swing"
);
}
);
