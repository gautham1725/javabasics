package com.errorCorrection;

public class Looping {
	
	public static void main(String[] args) {
		
		/*	int age =0;	
	if (  age >= 65 ) {
	System.out.println( "Age is greater than or equal to 65" );
	}
	else {
	System.out.println( "Age is less than 65 ");
	}
    
	*/ 		//worksheet 2-> 1(e)1
	
/*	int x = 1,total=0  ;
	while ( x <= 10 ) {
	
	total += x;
	++x;
}     */	//	 worksheet 2-> 1(e)2
		
		
		
		
	/*	int x=0,total=0;
		while ( x <= 100 )
		total += x;
		++x;	*/

		
	/*	int y=0;
		while (y> 0 )
		{
		System.out.println( y );
		++y;
		}		*/


		
		
	}
}

