package com.practice;

public class Main {
	
		public static void main(String ar[]) {
			
			//int len = args.length;
		//	int for = 2;
		//	byte b=1;
		//	float f = 1.2f;
			double d = 1.2D;
			//System.out.println(c);
			int c=0x45;
			c++;
			System.out.println(c);
		}
}
