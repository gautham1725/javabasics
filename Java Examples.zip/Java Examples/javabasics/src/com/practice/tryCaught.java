package com.practice;

public class tryCaught {
	public static void main(String[] args) {
	
	int arr[]= {1,2,3,4,5};
	//System.out.println(arr[6]);
	
	try {
		System.out.println(arr[6]);

		
	} catch(Exception e) {
		
		System.out.println("done");

	}

}
}