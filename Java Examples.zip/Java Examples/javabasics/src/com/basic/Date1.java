package com.basic;

public class Date1 {
	
	public static void main(String[] args)
	{
		/*Date d1 = new Date();
		d1.setDay(25);
		d1.setMonth(3);
		d1.setYear(1998);  */
		Date d2 =new Date(5,6,2018);
		d2.displayDate();
		
	}

}
