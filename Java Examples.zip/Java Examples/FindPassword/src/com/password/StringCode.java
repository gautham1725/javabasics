package com.password;

public class StringCode {

	public static void main(String[] args) {
		

	}

}
