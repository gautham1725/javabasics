package com.commanArgs;

public class CommandArgs {

	
	public static void main(String[] args) {
		
		
		//System.out.println(args[0]+" Technologies "+args[1] );
		// System.out.println("Welcome "+args[2]);
		
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
		System.out.println(a+b);
		
		
		
		
	}

	}
