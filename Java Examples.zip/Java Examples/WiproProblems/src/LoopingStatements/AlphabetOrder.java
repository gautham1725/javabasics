package LoopingStatements;

public class AlphabetOrder {

	public static void main(String[] args) {
		
		char a = 'r' ;
		char b = 'z' ;
		
		int x = (int)a;
		int y = (int)b;
		
		if(x>y) {
			System.out.println(a+" "+b);
		}
		else
			System.out.println(b+" "+a);
			
	}

}
