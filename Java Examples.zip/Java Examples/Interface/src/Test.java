
public class Test {
	public static void main(String[] args) {
		
		Travel t1 = new Bus();
		Travel t2 = new Rabbit(); 
		
		System.out.println(t1  instanceof Bus);
		
	//	t1.Bus();
	}

}
 