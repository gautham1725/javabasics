
public interface Travel {
	
		
	public void getSpeed();
}
