
public abstract class Animal implements Travel {
	

}

class Dog extends Animal{

	@Override
	public void getSpeed() {
		// TODO Auto-generated method stub
		
	}
}
		
	 class Cat extends Animal{

		@Override
		public void getSpeed() {
			// TODO Auto-generated method stub
			
		}
			}
			
	 class Rabbit extends Animal{

		@Override
		public void getSpeed() {
			// TODO Auto-generated method stub
			
		}
	}
