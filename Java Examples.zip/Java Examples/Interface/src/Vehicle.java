
public abstract class Vehicle implements Travel {
	
	
}
	
 class Car extends Vehicle{

	@Override
	public void getSpeed() {
		// TODO Auto-generated method stub
		
	}
}
		
	 class Cycle extends Vehicle{

		@Override
		public void getSpeed() {
			// TODO Auto-generated method stub
			
		}
			}
			
	 class Bus extends Vehicle{

		@Override
		public void getSpeed() {
			System.out.println();
			// TODO Auto-generated method stub
			
		}
	}


