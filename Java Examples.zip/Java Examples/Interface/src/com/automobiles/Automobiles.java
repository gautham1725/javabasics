package com.automobiles;

public interface Automobiles {

	
	public void print();
	
	
}
