package com.inheritance;

public class TwoDimension extends Shape {
	
	/*@Override
	public void printShape() {
	super.printShape();
	}*/
		
		public static void main(String[] args) {
			
			TwoDimension td1 = new TwoDimension();
			td1.printShape("square");
		}
	

}
