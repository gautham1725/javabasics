package com.inheritance;

public class Shape {
	
	String shape;
	
	public void printShape(String shape){
		System.out.println(shape);
	}

}
